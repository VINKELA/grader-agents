﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace interview
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello World!");
            var order = sortOrders(new List<string> { "zld 93 50","jid i will go now","jdk meet me in par" });
        }


        /*
         * Complete the 'sortOrders' function below.
         *
         * The function is expected to return a STRING_ARRAY.
         * The function accepts STRING_ARRAY orderList as parameter.
         */

        public static List<string> sortOrders(List<string> orderList)
        {
            // first iterate through the list 
            // get the prime orders
            // get the non prime orders
            // sort the prime orders according to the mentioned constraints
            var result = new List<string>();
            var primeOrders = new List<string>();
            var nonPrimeOrders = new List<string>();
            foreach (var order in orderList)
            {
                var list = order.Split(' ');
                int val;
                if (int.TryParse(list[1], out val))
                {
                    nonPrimeOrders.Add(order);
                }
                else
                {
                    primeOrders.Add(order);
                }
            }
            var sortById = primeOrders.OrderBy(x => x.Split(' ')[0]).ToList();
            var sortByName = sortById.OrderBy(x => x.Substring(3, (x.Length - 3))).ToList();
            result.AddRange(sortByName);
            result.AddRange(nonPrimeOrders);
            return result;
        }

    }

}
