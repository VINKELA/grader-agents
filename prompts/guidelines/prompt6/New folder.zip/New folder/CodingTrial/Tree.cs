﻿using System;
using System.Collections.Generic;
using System.ComponentModel.Design;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CodingTrial
{
    public class TreeNode
    {
        public int Data {  get; set; }
        public TreeNode? Left { get; set; }
        public TreeNode? Right { get; set; }

    }
    internal class Tree
    {
        public TreeNode? Root { get; set; }
        public bool Add(int value)
        {
            Root = Add(Root, value);
            return false;
        }
        public void LoadTree(int[] data)
        {

            for (int i = 0; i < data.Length; i++)
            {
                Add(data[i]);
            }
        }
        private TreeNode Add(TreeNode root ,int value) 
        { 
            if(root == null)
            {
                return new TreeNode
                {
                    Data = value,
                };
            }
            else if(root.Data > value)
            {
                root.Left = Add(root.Left, value);
            }
            else if(root.Data < value)
            {
                root.Right = Add(root.Right, value);
            }
            return root;
       
        }
        private bool Find(int value, TreeNode tree) 
        {
            if (tree == null)
            {
                return false;
            }
            else if (tree.Data > value) 
            {
                return Find(value, tree.Left);
            }
            else if(tree.Data < value)
            {
               return Find(value, tree.Right);
            }
            else
            {
                return true;
            }  
        }
        public TreeNode GetMinValue(TreeNode tree)
        {
            if(tree.Left == null)
            {
                return tree;
            }
            else
            {
                return GetMinValue(tree.Left);
            }
            
        }
        public void InOrderTransversal(TreeNode tree)
        {
            if(tree != null)
            {
                InOrderTransversal(tree.Left);
                Console.WriteLine(tree.Data);
                InOrderTransversal(tree.Right);
            }  
        }
        public void PreOrderTransversal(TreeNode tree)
        {
            if (tree != null)
            {
                Console.WriteLine(tree.Data);
                PreOrderTransversal(tree.Left);
                PreOrderTransversal(tree.Right);
            }
        }
        public void PostOrderTransversal(TreeNode tree)
        {
            if(tree != null)
            {
                PostOrderTransversal(tree.Left);
                PostOrderTransversal(tree.Right);
                Console.WriteLine(tree.Data);
            }
           
        }
        public int GetTreeDepth(TreeNode tree)
        {
            if(tree == null)
            {
                return 0;
            }
            else
            {
                return 1 +  Math.Max(GetTreeDepth(tree.Right), GetTreeDepth(tree.Left));
            }
        }

        public TreeNode? Remove(TreeNode tree, int  value)
        {
            if (tree == null) return tree;
            if (tree.Data > value)
            {
                tree.Left = Remove(tree.Left, value);
            }
            else if (tree.Data < value)
            {
                tree.Right = Remove(tree.Right, value);
            }
            else
            {
                //this is the node we are trying trying to remove
                //if it has one brach, replace with one branch
                if(tree.Left != null && tree.Right == null)
                {
                    return tree.Left;
                }
                else if(tree.Right != null && tree.Left == null)
                {
                    return tree.Right;
                }
                //if it has two branch, replace with the mininum node in the right branch
                else if (tree.Left != null && tree.Right != null)
                {
                    var minRight = GetMinValue(tree.Right);
                    tree.Data = minRight.Data;
                    tree.Right = Remove(tree.Right, minRight.Data);
                    
                }

            }
            return tree;

        }
        public bool Find(int value)
        {
            return Find(value, Root);
        }

    }
}
