﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security;
using System.Text;
using System.Threading.Tasks;

namespace CodingTrial
{
    public class BubbleSort
    {
        public static List<int> Sort(List<int> list) 
        { 
            //iterate through the list n - 1 times
            var n = list.Count;
            for (int i = 0; i < n - 1; i++) 
            {
                //starting from the front at each time
                for(int j = 0; j < n - i - 1; j++) 
                {
                   var current = list[j];
                    var next = list[j + 1];
                    if(current > next) 
                    {
                        list[j + 1] = current;
                        list[j] = next;
                    }
                }
            }
            return list;
        }
    }
}
