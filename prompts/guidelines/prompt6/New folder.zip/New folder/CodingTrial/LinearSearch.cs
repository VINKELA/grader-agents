﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CodingTrial
{
    internal class LinearSearch
    {
        public bool Search(int number, int[] elements) 
        {
            foreach (int element in elements) 
            {
                if (number == element)
                {
                    return true;
                }
            }
            return false;
        }
    }
}
