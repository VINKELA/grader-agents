﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CodingTrial
{
    public class LinkedListNode
    {
        public int Data { get; set; }
        public LinkedListNode Next { get; set; }
    }
    internal class LinkedList
    {
        public LinkedListNode Head { get; set; }
        public LinkedListNode Add(int value)
        {
            Head = Add(value, Head);
            return Head;
        }

        private LinkedListNode Add(int value, LinkedListNode head)
        {
            if(head == null)
            {
                return new LinkedListNode()
                {
                    Data = value
                };
            }
            var cursor = head;
            while (cursor.Next != null) 
            {
                cursor = cursor.Next;
            }
            cursor.Next = new LinkedListNode 
            { 
                Data = value,
            };
            return head;
        }
    }
}
