﻿// See https://aka.ms/new-console-template for more information
using CodingTrial;

//selection sort

//merge sort
//binary search
//linear search
//Tree
//Tries
var t = new LinkedList();
for(var i = 0; i < 6; i++)
{
    t.Add(i);
}

Console.WriteLine(t.ToString());

//linkedList
//graph
//hash maps
//cache

