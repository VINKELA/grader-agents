﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CodingTrial
{
    public class MergeSort
    {
      
        public static int[] Sort(int[] list)
        {
            var n = list.Length;
            if (n == 1) return list;
            var left = 0;
            var right = n - 1;
            var mid = n / 2;           
            //sort left
            //get left
            var nl = mid - left;
            var ll = new int[nl];
            for (int i = 0; i < nl; i++) 
            {
                ll[i] = list[i];
            }
            var sll = Sort(ll);
            //get right
            var nr = n % 2 == 1 ? mid - left + 1: mid - left;
            var lr = new int[nr];
            for(int i = 0; i < nr; i++) 
            {
                lr[i] = list[mid + i];
            }
            //sort right
            var srl = Sort(lr);
            //merge left and right list
            list = MergeList(sll, srl);
            
            return list;
        }

        private static int[] MergeList(int[] sll, int[] srl)
        {
            var nl = sll.Length;
            var rl = srl.Length;
            var lcursor = 0;
            var rcursor = 0;
            var result = new int[nl + rl];
            var j = 0;
            while (lcursor < nl && rcursor < rl) 
            {
                if (srl[rcursor] > sll[lcursor]) 
                {
                    result[j] = sll[lcursor];
                    lcursor++;
                }
                else
                {
                    result[j] = srl[rcursor];
                    rcursor++;
                }
                j++;

            }
            while (rl > rcursor)
            {
                result[j] = srl[rcursor];
                rcursor++;
                j++;

            }
            while (nl > lcursor)
            {
                result[j] = sll[lcursor];
                lcursor++;
                j++;

            }
            return result;
        }
    }  
}
