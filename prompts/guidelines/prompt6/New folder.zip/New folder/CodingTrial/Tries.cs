﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CodingTrial
{
    public class TrieNode
    {
        public TrieNode[] children {  get; set; }
        public TrieNode() 
        { 
            children = new TrieNode[26];
        }
        public bool IsWord { get; set; }
    }
    internal class Tries
    {
        public TrieNode Root { get; set; }
        public void Add(string word)
        {
            Root = Add(Root, word);
        }
        public TrieNode Add(TrieNode root, string word) 
        {
            if (root == null)
            {
                root = new TrieNode();  
            }
            var cursor = root;
            var lowerWord = word.ToLower();

            for (int i = 0; i < lowerWord.Length; i++) 
            { 
                var character = lowerWord[i];
                var index =  character - 'a';
                if (cursor == null)
                {
                    root = new TrieNode();
                }
                if (cursor.children[i] == null)
                {
                    cursor.children[index] = new TrieNode();
                }
                cursor = cursor.children[index];
                if (i == lowerWord.Length - 1)
                {
                    cursor.IsWord = true;
                }

            }
            return root;
        }
        public bool Find(string word, TrieNode Trie)
        {

            var lowerCase = word.ToLower();
            var cursor = Trie;
            for(int i = 0; i < lowerCase.Length; i++) 
            { 
                var character = lowerCase[i];
                var index =  character - 'a';
                var current = cursor.children[index];
                if (current == null) return false;
                cursor = current;
                if (i == lowerCase.Length - 1)
                {
                    return current.IsWord;
                }
            }
            return false;
        }
    }
}
