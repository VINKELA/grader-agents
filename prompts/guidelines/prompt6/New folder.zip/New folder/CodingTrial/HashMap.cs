﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CodingTrial
{
    //node, some sort of value and 
    internal class HashMap
    {
        //a hash function that hashes to a key
        //an arry or dictionary, with key above
    }
}
