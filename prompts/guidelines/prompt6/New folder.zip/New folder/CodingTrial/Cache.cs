﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CodingTrial
{
    public class CacheNode
    {
        public string Key { get; set; }
        public object Data { get; set; } 
        public CacheNode Next { get; set; }
    }
    //a node in a cache is a key value, where key is the query(dictionary)
    public class CacheLinkedList
    {
        public CacheNode Root { get; set; }
        public CacheNode Tail { get; set; }
        public CacheNode AppendToFront(CacheNode node)
        {
            //using the cursor, check for node with value, append to front
            if(LookUp(node) == null)
            {
                //swap with front
            }
        }
        // lookup
        public CacheNode LookUp(CacheNode node)
        {
            var cursor = Root;
            while (cursor != null || cursor.Data != node.Data) 
            { 
                cursor = cursor.Next;
            }
            return cursor;
        }
    }

    internal class Cache
    {

        //a list of nodes
        public  CacheLinkedList List { get; set; }
        // max size
        public int Size { get; set; }
        // function to append to front
         
        public int MaxSize { get; set; }
        //function to remove from back
        // function to find
        
    }
}
