﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CodingTrial
{
    internal class BinarySearch
    {
        public static bool Search(int number, int[] elements)
        {
            var sortedList = MergeSort.Sort(elements);
            return SearchList(number, sortedList);
        }

        private static bool SearchList(int number, int[] sortedList)
        {
            var n = sortedList.Length;
            if(n == 1)
            {
                return number == sortedList[0];
            }
            var m = n / 2;
            var l = 0;
            var r = n - 1;
            var left = new int[m - l];
            for (var i = 0; i < left.Length; i++) 
            {
                left[i] = sortedList[i];
            }
            var right = new int[n - left.Length];
            for (int i = 0; i < right.Length; i++)
            {
                right[i] = sortedList[m + i];
            }
            if (sortedList[m] > number)
            {
               return SearchList(number, left);
            }
            else
            {
                return SearchList(number, right);
            }

        }
    }
}
