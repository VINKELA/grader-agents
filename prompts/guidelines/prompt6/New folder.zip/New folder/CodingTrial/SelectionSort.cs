﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CodingTrial
{
    public class SelectionSort
    {
        public static List<int> Sort(List<int> list) 
        {
            //iterate through the list n times
            //in each time, get the min in list
            for (int i = 0; i < list.Count; i++) 
            {
                int min = int.MaxValue;
                int minAt = i;
                for (int j = i;  j < list.Count; j++) 
                {
                    if (list[j] < min) 
                    {
                        min = list[j];
                        minAt = j;
                    }
                }
                var temp = list[i];
                list[i] = min;
                list[minAt] = temp;
            }
            return list;

        }
    }
}
