﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Algorithms
{
    public class SelectionSort
    {
        public static void Sort(List<int> list) 
        {
            var length = list.Count;
            //iterate through the list
            var min = int.MaxValue;
            for (int i = 0; i < length; i++)
            {
                // on each iteration, select the minimum value

                for (int j = i; j < length;j ++)
                {
                    if (list[j] < min)
                    {
                        min = list[j];
                    }
                }
                list[i] = min;
            }
            Console.WriteLine(list.ToString());
        }
    }
}
