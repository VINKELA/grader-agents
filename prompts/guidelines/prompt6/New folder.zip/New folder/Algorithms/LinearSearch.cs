﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Algorithms
{
    public class LinearSearch
    {
        public static bool Find(List<int> list, int target) 
        {
            //search through the array
            //foreach element
            foreach (var item in list)
            {
                //if equal to target then return true
                if(target == item) return true;

            }
            //if after exhausting the list and target is not found, return false
            return false;
        }
    }
}
