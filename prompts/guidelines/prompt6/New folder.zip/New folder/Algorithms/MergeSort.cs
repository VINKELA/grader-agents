﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Algorithms
{
    public class MergeSort
    {
        public void Sort(List<int> list)
        {

        }
        private void Sort(List<int> list, int left, int right) 
        {
          
        }


    }
}
