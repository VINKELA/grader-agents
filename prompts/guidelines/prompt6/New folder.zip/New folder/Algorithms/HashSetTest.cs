﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Algorithms
{
    public class HashSetTest
    {
        public static void Test() 
        {
            // Using HashSet class
            HashSet<string> myhash = new HashSet<string>();

            // Add the elements in HashSet
            // Using Add method
            myhash.Add("C");
            myhash.Add("C++");
            myhash.Add("C#");
            myhash.Add("Java");
            myhash.Add("Ruby");
            var value = myhash.TryGetValue("C", out var val);
            Console.WriteLine(val);
        }
    }
}
