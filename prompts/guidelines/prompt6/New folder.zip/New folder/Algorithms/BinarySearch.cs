﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Algorithms
{
    public class BinarySearch
    {
        public static bool Find(List<int> list, int target)
        {
            return Find(list, target, 0, list.Count - 1);
        }
        private static bool Find(List<int> list, int target, int left, int right) 
        {
            //assume a sorted list
            var n = list.Count;
            //get the middle of list
            var middle = left + (right - left) / 2;
            //if middle is target return middle
            if (list[middle] == target)
            {
                return true;
            }
            //else if middle is greater than target, search right
            else if (list[middle] > target)
            {
                var start = left;
                var end = middle;
                Find(list, target, start, end);
            }
            //else if middle is less than target search left
            else if (list[middle] < target) 
            {
                var start = middle + 1;
                var end = n - 1;
                Find(list, target, start, end);
            }
            //return false if not found
            return false;
        }

    }
}
