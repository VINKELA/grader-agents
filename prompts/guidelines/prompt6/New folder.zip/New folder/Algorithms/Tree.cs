﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Algorithms
{

    public class Tree
    {
        public TreeNode? Root;
        public class TreeNode
        {
            public TreeNode? Right;
            public TreeNode? Left;
            public int data;
        }
        public void AddNode(int value)
        {
            Root = AddNode(value, Root);
        }
        private TreeNode? AddNode(int value, TreeNode tree) 
        {
            //tree does not contain node, add value as root node
            if (tree == null)
            {
                var newNode = new TreeNode
                {
                    data = value
                };
                return newNode;
            }
            //if tree contains an object, check if value is less than data
            else if (value > tree.data) 
            {
                tree.Right =  AddNode(value, tree.Right);
            }
            else if(value < tree.data)
            {
                tree.Left =  AddNode(value, tree.Left);
            }
            return tree;
        }
        private TreeNode RemoveNode(int value, TreeNode node) 
        {
            //find the node
            
            if(node.data < value)
            {
                node.Right = RemoveNode(value, node.Right);
            }
           else if(node.data > value)
            {
                node.Left = RemoveNode(value, node.Left);
            }
            else
            {

                //node contains one branch
                if (node.Left == null)
                {
                    return node.Right;
                }
                else if (node.Right == null) 
                { 
                    return node.Left;
                }
                //node contains two branches
                var minRightValue = GetMinValue(node.Right);
                node.data = minRightValue;
                node.Right = RemoveNode(minRightValue, node.Right);
            }
            //remove the node
            return node;
        }
        public int GetTreeDepth(TreeNode node)
        {
            if(node == null)
            {
                return 0;
            }
            else
            {
                return 1  + Math.Max(GetTreeDepth(node.Left), GetTreeDepth(node.Right));
            }
        }
        public int GetMinValue(TreeNode node)
        {
            if(node.Left == null)
            {
                return node.data;
            }
            return GetMinValue(node.Left);
        }
        private void InOrderTransversal(TreeNode treeNode) 
        {
            if(treeNode != null)
            {
                InOrderTransversal(treeNode.Left);
                Console.Write($" {treeNode.data}");
                InOrderTransversal(treeNode.Right);
            }
          
        }
        private void PostOrderTransversal(TreeNode treeNode)
        {
            if(treeNode != null)
            {
                PostOrderTransversal(treeNode.Right);
                PostOrderTransversal(treeNode.Left);
                Console.Write($" {treeNode.data}");
            }
           

        }
        private void PreOrderTransversal(TreeNode treeNode)
        {
            Console.Write($" {treeNode.data}");
            PreOrderTransversal(treeNode.Left);
            PreOrderTransversal(treeNode.Right);
        }

        public void InOrderTransversal()
        {
            InOrderTransversal(Root);
        }
        public void PreOrderTransversal()
        {
            PreOrderTransversal(Root);
        }
        public void PostOrderTransversal()
        {
            PostOrderTransversal(Root);
        }

        public void RemoveNode(int value)
        {
            RemoveNode(value, Root);
        }
    }
}
