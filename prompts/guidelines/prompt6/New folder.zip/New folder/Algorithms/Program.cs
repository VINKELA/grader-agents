﻿// See https://aka.ms/new-console-template for more information

using Algorithms;

HashSetTest.Test();
    
