﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Algorithms
{
    public class Editor
    {
        public string value = "";
        public Stack<(int, string?)> operations;
        public Editor(string initialValue = "")
        {
            value = initialValue;
            operations = new Stack<(int, string?)>();

        }
        private void updateOperation(int operation, string? value = null, bool isUndoOperation = false)
        {
            if (!isUndoOperation) 
            {
                operations.Push((operation, value));
            }
        }
        public void append(string x, bool isUnOperation = false)
        {
            value = value + x;
            updateOperation(1, x, isUnOperation);
        }
        public void undo()
        {
            var lastOperation = operations.Pop();
            var op = lastOperation.Item1;
            var value = lastOperation.Item2;
            switch (op)
            {
                case 1:
                    var k = value.Length;
                    delete(k, true);
                    break;
                case 2:
                    var removed = lastOperation.Item2;
                    append(removed, true);
                    break;
            }
        }
        public void delete(int k, bool undo= false)
        {
            var deleteCount = 0;
            var length = value.Length;
            var starting = length - k;
            var lastItem = value.Substring(starting, k);

            while (value.Length > 0 && deleteCount < k)
            {
                value = value.Remove(length - 1, 1);
                deleteCount = deleteCount + 1;
                length = value.Length;
            }
         updateOperation(2, lastItem, undo);
        }
        public void print(int k)
        {
            if (value.Length < k) return;
            Console.WriteLine(value[k - 1]);
        }

    }
}
