﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Algorithms
{
    public class BubbleSort
    {
        public static void Sort(List<int> list)
        {
            var length = list.Count;
            //iterate through the elements
            for (int i = 0; i < length - 1; i++)
            {
                // compare with all other elements
                for (int j = 0; j < length - i - 1; j++)
                {
                    //if greater than succeeding element
                    var item = list[j];

                    if (item > list[j + 1])
                    {
                        //swap with the element
                        var temp = list[j];
                        list[j] = list[j + 1];
                        list[j] = temp;
                    }
                }
            }
        }
    }
}
